#include <stdio.h>


int main(int argc, char *argv[])
{
  printf("Hello world! (fetched from https://github.com/gvendranas/yocto_hello_world)\n");
  return 0;
}
